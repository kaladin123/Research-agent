"""End-to-end demo: run the central Research Agent against the USP MCP server.

Prereq: the USP server must be running in another terminal:
    python -m usp_lob_agent.server

Then:
    python main.py "How does ingestion handle failures and retries?"

The demo query is chosen to exercise the full arc:
  round 1: SIPOC says manual retry, code says automatic -> tier-1 conflict
           escalated in unresolved_conflicts -> evaluator says refine
  round 2: refined question ('what is deployed in production?') retrieves
           the deployment note -> conflict resolvable -> evaluator says done
  reconcile: cross-round resolution names the deployment note as winner
  synthesize: final answer cites sources and notes the superseded SIPOC
"""

import asyncio
import json
import sys

from dotenv import load_dotenv

load_dotenv()

from google.adk.runners import Runner  # noqa: E402
from google.adk.sessions import InMemorySessionService  # noqa: E402
from google.genai import types  # noqa: E402

from central_research_agent.agent import root_agent  # noqa: E402

APP_NAME = "research_agent_mvp"
USER_ID = "mahesh"
SESSION_ID = "demo-session-001"

DEFAULT_QUERY = "How does the USP ingestion pipeline handle failures and retries?"


async def main(query: str) -> None:
    session_service = InMemorySessionService()
    await session_service.create_session(
        app_name=APP_NAME,
        user_id=USER_ID,
        session_id=SESSION_ID,
        # Initial state: templated keys must exist before first use.
        state={"original_query": query, "findings": [], "finding_hashes": []},
    )

    runner = Runner(
        agent=root_agent, app_name=APP_NAME, session_service=session_service
    )

    print(f"\n=== Query: {query}\n")

    async for event in runner.run_async(
        user_id=USER_ID,
        session_id=SESSION_ID,
        new_message=types.Content(role="user", parts=[types.Part(text=query)]),
    ):
        # Trace the orchestration: who acted, what they produced.
        if event.content and event.content.parts:
            for part in event.content.parts:
                if getattr(part, "text", None):
                    text = part.text.strip()
                    if text:
                        print(f"--- [{event.author}]\n{text[:600]}\n")
        if event.actions and event.actions.escalate:
            print(f"--- [{event.author}] escalate=True -> loop exits\n")

    session = await session_service.get_session(
        app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID
    )

    print("=" * 72)
    print("PLAN:")
    print(json.dumps(session.state.get("plan"), indent=2, default=str))
    print(f"\nROUNDS RUN: {len(session.state.get('findings', []))}")
    print("LOOP EXIT:", session.state.get("loop_exit"))
    print("\nRECONCILIATION:")
    print(json.dumps(session.state.get("reconciliation"), indent=2, default=str))
    print("\nFINAL ANSWER:\n")
    print(session.state.get("final_answer"))


if __name__ == "__main__":
    q = " ".join(sys.argv[1:]) or DEFAULT_QUERY
    asyncio.run(main(q))
