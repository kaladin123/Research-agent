from . import agent  # noqa: F401  (adk web / adk run discovery)
