"""Model + MCP wiring for the central Research Agent.

Azure OpenAI GPT-4.1 via LiteLLM (same pattern as Astra). LiteLLM reads
AZURE_API_KEY / AZURE_API_BASE / AZURE_API_VERSION from the environment.
"""

import os

from google.adk.models.lite_llm import LiteLlm

AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT", "gpt-4.1")
USP_MCP_URL = os.getenv("USP_MCP_URL", "http://localhost:8001/mcp")


def azure_model() -> LiteLlm:
    return LiteLlm(model=f"azure/{AZURE_DEPLOYMENT}")


def usp_mcp_toolset():
    """MCPToolset pointed at the USP LOB agent.

    The connection-params class has moved across ADK releases, so try the
    current location first and fall back.
    """
    from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset

    try:
        from google.adk.tools.mcp_tool.mcp_session_manager import (
            StreamableHTTPConnectionParams as HttpParams,
        )
    except ImportError:  # older ADK
        from google.adk.tools.mcp_tool.mcp_toolset import (
            StreamableHTTPServerParams as HttpParams,
        )

    return MCPToolset(
        connection_params=HttpParams(url=USP_MCP_URL),
        tool_filter=["usp_research"],
    )
