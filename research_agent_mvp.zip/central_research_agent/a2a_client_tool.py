"""usp_research over A2A -- drop-in alternative transport for the consult step.

F1872578 names MCP as the RA <-> LOB interaction layer, so MCP stays the
default (LOB_TRANSPORT=mcp). Setting LOB_TRANSPORT=a2a swaps this function
tool in instead: the function keeps the name `usp_research` and the same
signature as the MCP tool, so the consult agent's instruction, the recorded
finding shape, the evaluator, and the exit logic are all untouched --
transport is the only thing that changes. That neutrality is itself part of
the federation story.

Client pattern matches a2a-sdk 0.x: resolve the AgentCard from
/.well-known/, then message/send.
"""

import json
import os
import uuid

import httpx
from a2a.client import A2ACardResolver, A2AClient
from a2a.types import MessageSendParams, SendMessageRequest

USP_A2A_URL = os.getenv("USP_A2A_URL", "http://localhost:8002")


def _extract_text(response) -> str:
    """Pull the text part out of a message/send response, tolerating shape
    differences across a2a-sdk 0.x minor versions."""
    data = response.model_dump(mode="python", exclude_none=True)
    result = data.get("result", {})
    parts = result.get("parts") or (result.get("status", {}).get("message", {}) or {}).get(
        "parts", []
    )
    for part in parts:
        text = part.get("text") or part.get("root", {}).get("text")
        if text:
            return text
    return json.dumps({"error": "no text part in A2A response", "raw": str(data)[:400]})


async def usp_research(
    sub_question: str,
    context: dict | None = None,
    constraints: dict | None = None,
) -> dict:
    """Ask the USP domain expert a research question (A2A transport).

    Same contract as the MCP tool: returns a UspResearchResponse dict with
    finding, confidence, coverage, evidence, unresolved_conflicts, and
    suggested_followups.
    """
    payload = json.dumps(
        {
            "sub_question": sub_question,
            "context": context or {},
            "constraints": constraints or {},
        }
    )

    async with httpx.AsyncClient(timeout=60.0) as client:
        resolver = A2ACardResolver(httpx_client=client, base_url=USP_A2A_URL)
        card = await resolver.get_agent_card()
        a2a_client = A2AClient(httpx_client=client, agent_card=card)

        request = SendMessageRequest(
            id=str(uuid.uuid4()),
            params=MessageSendParams(
                message={
                    "role": "user",
                    "parts": [{"kind": "text", "text": payload}],
                    "messageId": uuid.uuid4().hex,
                }
            ),
        )
        response = await a2a_client.send_message(request)

    text = _extract_text(response)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {
            "finding": "",
            "confidence": "low",
            "coverage": "none",
            "evidence": [],
            "unresolved_conflicts": [],
            "suggested_followups": [],
            "error": f"Unparseable A2A response: {text[:300]}",
        }
