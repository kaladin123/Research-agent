"""Central Research Agent -- A2A server.

Wraps the full ADK pipeline (decompose -> plan -> loop -> reconcile ->
synthesize) behind an AgentCard, making the RA itself an invocable A2A peer
-- e.g. for the Forge back-end or any other card-aware agent.

Each incoming A2A message runs one complete research invocation in a fresh
ADK session (the RA is stateless across requests by design; loop memory
lives in session state for the duration of one run only).

Run:  python -m central_research_agent.a2a_server
(The USP LOB agent must be reachable over the configured transport.)
"""

import os
import sys
import uuid

from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from google.adk.runners import Runner  # noqa: E402
from google.adk.sessions import InMemorySessionService  # noqa: E402
from google.genai import types  # noqa: E402

from central_research_agent.agent import root_agent  # noqa: E402
from central_research_agent.agent_card import research_agent_card  # noqa: E402
from common.a2a_wrapper import serve_a2a  # noqa: E402

HOST = os.getenv("RA_A2A_HOST", "0.0.0.0")
PORT = int(os.getenv("RA_A2A_PORT", "8003"))
BASE_URL = os.getenv("RA_A2A_URL", f"http://localhost:{PORT}")

APP_NAME = "research_agent_mvp"
_session_service = InMemorySessionService()
_runner = Runner(
    agent=root_agent, app_name=APP_NAME, session_service=_session_service
)


async def handle(user_input: str) -> str:
    query = user_input.strip()
    session_id = uuid.uuid4().hex

    await _session_service.create_session(
        app_name=APP_NAME,
        user_id="a2a-peer",
        session_id=session_id,
        state={"original_query": query, "findings": [], "finding_hashes": []},
    )

    async for _event in _runner.run_async(
        user_id="a2a-peer",
        session_id=session_id,
        new_message=types.Content(role="user", parts=[types.Part(text=query)]),
    ):
        pass

    session = await _session_service.get_session(
        app_name=APP_NAME, user_id="a2a-peer", session_id=session_id
    )
    return session.state.get("final_answer") or "No answer was produced."


if __name__ == "__main__":
    serve_a2a(research_agent_card(BASE_URL), handle, HOST, PORT)
