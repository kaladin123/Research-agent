"""Central Research Agent -- root wiring.

    decompose -> plan -> [ consult -> record -> evaluate -> exit ]* ->
    reconcile -> synthesize

Maps 1:1 onto the seven steps of the runtime research path:
  step 1  decompose_agent
  step 2  plan_agent
  steps 3-5  consult_loop (LoopAgent)
  step 6  reconcile_agent
  step 7  synthesis_agent

Exposed as `root_agent` so `adk run` / `adk web` pick it up, and importable
by main.py for the scripted demo.
"""

import os
import sys

from google.adk.agents import LoopAgent, SequentialAgent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from central_research_agent.sub_agents.consult import consult_agent  # noqa: E402
from central_research_agent.sub_agents.decompose import decompose_agent  # noqa: E402
from central_research_agent.sub_agents.evaluate import evaluate_agent  # noqa: E402
from central_research_agent.sub_agents.exit_checker import exit_checker  # noqa: E402
from central_research_agent.sub_agents.plan import plan_agent  # noqa: E402
from central_research_agent.sub_agents.reconcile import reconcile_agent  # noqa: E402
from central_research_agent.sub_agents.record_finding import record_finding  # noqa: E402
from central_research_agent.sub_agents.synthesize import synthesis_agent  # noqa: E402

MAX_LOOP_ITERATIONS = 4

consult_loop = LoopAgent(
    name="consult_loop",
    description="Iterative LOB consultation with deterministic exit.",
    max_iterations=MAX_LOOP_ITERATIONS,
    sub_agents=[
        consult_agent,
        record_finding,
        evaluate_agent,
        exit_checker,
    ],
)

root_agent = SequentialAgent(
    name="central_research_agent",
    description=(
        "Central Research Agent: decomposes a research query, plans domain "
        "consultation, iteratively consults LOB agents over MCP, reconciles "
        "conflicts, and synthesizes a cited answer."
    ),
    sub_agents=[
        decompose_agent,
        plan_agent,
        consult_loop,
        reconcile_agent,
        synthesis_agent,
    ],
)
