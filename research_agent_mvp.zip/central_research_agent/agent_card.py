"""AgentCard + AgentSkill for the central Research Agent (A2A compliance)."""

from a2a.types import AgentCapabilities, AgentCard, AgentSkill

FEDERATED_RESEARCH_SKILL = AgentSkill(
    id="federated_research",
    name="Federated research orchestration",
    description=(
        "Answers a research query through federated orchestration: "
        "decomposes the query, plans LOB/domain consultation, iteratively "
        "consults LOB agents (deterministic loop exit on done / no-progress "
        "/ max iterations), reconciles cross-round conflicts, and returns a "
        "synthesized answer with source citations. Owns no domain "
        "knowledge -- all retrieval and domain reasoning stays inside "
        "LOB-owned agents."
    ),
    tags=["research", "orchestration", "federated", "multi-agent", "planning"],
    examples=[
        "How does the USP ingestion pipeline handle failures and retries?",
        "What are the stages of the ingestion pipeline and where is data "
        "vectorized?",
    ],
)

def research_agent_card(base_url: str) -> AgentCard:
    return AgentCard(
        name="central-research-agent",
        description=(
            "Central Research Agent / Context Engine MVP (F1872578). "
            "Planning and orchestration layer of the federated research "
            "architecture: Forge -> Research Agent -> LOB agents. "
            "Consumable as an A2A peer by Forge back-end or other agents."
        ),
        url=base_url,
        version="0.1.0",
        default_input_modes=["text"],
        default_output_modes=["text"],
        capabilities=AgentCapabilities(streaming=False),
        skills=[FEDERATED_RESEARCH_SKILL],
    )
