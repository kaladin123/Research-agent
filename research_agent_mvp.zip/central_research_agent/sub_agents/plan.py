"""Step 2 -- Plan: decide which domain path(s) to consult, in what order.

In the MVP every step routes to USP, so this looks trivial -- but the spec
explicitly requires "plan which domain path(s) should be consulted", and an
explicit plan artifact in session state is the auditable proof of central
orchestration. When Optum Rx / XLOB come online, only this step's routing
knowledge grows; the loop, evaluator, and reconciliation stay untouched.
"""

import os
import sys

from google.adk.agents import LlmAgent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from central_research_agent.config import azure_model  # noqa: E402
from common.contracts import ConsultationPlan  # noqa: E402

plan_agent = LlmAgent(
    name="plan_agent",
    model=azure_model(),
    description="Produces the domain consultation plan.",
    instruction=(
        "You are the planning step of a central research agent.\n"
        "The decomposition of the user's query is: {decomposition}\n\n"
        "Produce a consultation plan: for each sub-question, assign the "
        "domain to consult and an order. The only available domain in this "
        "MVP is USP (United States Pharmacopeia line of business -- owns "
        "ingestion, SIPOCs, codebases, SharePoint knowledge). Route every "
        "sub-question to domain 'USP'. Give a one-line rationale per step."
    ),
    output_schema=ConsultationPlan,
    output_key="plan",
)
