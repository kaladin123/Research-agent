"""Step 1 -- Decompose: break the user's query into sub-questions."""

import os
import sys

from google.adk.agents import LlmAgent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from central_research_agent.config import azure_model  # noqa: E402
from common.contracts import Decomposition  # noqa: E402

decompose_agent = LlmAgent(
    name="decompose_agent",
    model=azure_model(),
    description="Breaks the research query into focused sub-questions.",
    instruction=(
        "You are the decomposition step of a central research agent.\n"
        "Break the user's research query into 1-3 focused, independently "
        "answerable sub-questions. Fewer is better -- only split when the "
        "query genuinely contains distinct concerns.\n"
        "Keep each sub-question self-contained (no pronouns referring to "
        "other sub-questions)."
    ),
    # output_schema gives validated structured output. Note the ADK rule:
    # an agent with output_schema cannot also use tools -- fine here.
    output_schema=Decomposition,
    output_key="decomposition",
)
