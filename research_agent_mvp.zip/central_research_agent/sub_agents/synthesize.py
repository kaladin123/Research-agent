"""Step 7 -- Synthesize: assemble the final answer for Forge."""

import os
import sys

from google.adk.agents import LlmAgent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from central_research_agent.config import azure_model  # noqa: E402

synthesis_agent = LlmAgent(
    name="synthesis_agent",
    model=azure_model(),
    description="Assembles the final, cited research answer.",
    instruction=(
        "You are the final synthesis step of a central research agent.\n\n"
        "Original query: {original_query}\n"
        "Decomposition: {decomposition}\n"
        "Consultation plan: {plan}\n"
        "Findings: {findings}\n"
        "Reconciliation of conflicts: {reconciliation}\n"
        "Loop exit info: {loop_exit?}\n\n"
        "Write the final answer to the original query:\n"
        "- Ground every claim in the findings; cite source_ids inline in "
        "square brackets.\n"
        "- Where a conflict was reconciled, state the resolved truth and "
        "briefly note what the superseded source said (with its citation) "
        "-- this shows the conflict was handled, not hidden.\n"
        "- If the loop exited on no_progress, or any finding has coverage "
        "'none' or an error, add a short 'Limitations' note describing what "
        "could not be established. Never claim completeness you do not "
        "have.\n"
        "- Plain prose, no headers unless the answer genuinely needs "
        "structure. Concise."
    ),
    output_key="final_answer",
)
