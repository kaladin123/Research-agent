"""RecordFinding -- deterministic custom BaseAgent (no LLM).

LlmAgent output_key OVERWRITES a state key; it can't append to a list. This
agent parses state['last_finding'] and appends it to state['findings'] via a
proper state_delta event.

It is also the failure boundary: if the consult step returned garbage or the
MCP call failed, we record a synthetic coverage='none' finding instead of
crashing -- so 'what happens when USP is down?' has an answer that is not a
stack trace. The exit logic and synthesis then handle partial results.
"""

import json
import os
import sys
from typing import AsyncGenerator

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


def _parse_finding(raw) -> dict:
    if isinstance(raw, dict):
        return raw
    text = str(raw).strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        text = text[start : end + 1]
    return json.loads(text)


class RecordFinding(BaseAgent):
    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        state = ctx.session.state
        findings = list(state.get("findings", []))

        try:
            finding = _parse_finding(state.get("last_finding", ""))
        except (json.JSONDecodeError, ValueError) as exc:
            finding = {
                "finding": "",
                "confidence": "low",
                "coverage": "none",
                "evidence": [],
                "unresolved_conflicts": [],
                "suggested_followups": [],
                "error": f"Failed to obtain a valid LOB response: {exc}",
            }

        finding["iteration"] = len(findings) + 1
        findings.append(finding)

        yield Event(
            author=self.name,
            actions=EventActions(state_delta={"findings": findings}),
        )


record_finding = RecordFinding(name="record_finding")
