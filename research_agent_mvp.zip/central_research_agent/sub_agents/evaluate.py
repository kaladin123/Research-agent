"""Step 5a -- Evaluate: judge the findings, produce a structured LoopStatus.

This is the promotion of the conflict_detected boolean into a status object.
The spec names three loop-continue reasons -- conflicting, incomplete, or
competing findings -- so the verdict carries reasons, plus the refined
question for the next iteration. The evaluator only WRITES the status; the
deterministic ExitChecker decides whether the loop actually exits.
"""

import os
import sys

from google.adk.agents import LlmAgent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from central_research_agent.config import azure_model  # noqa: E402
from common.contracts import LoopStatus  # noqa: E402

evaluate_agent = LlmAgent(
    name="evaluate_agent",
    model=azure_model(),
    description="Evaluates findings and decides done vs refine.",
    instruction=(
        "You are the evaluation step of an iterative research loop.\n\n"
        "Original query: {original_query}\n"
        "Consultation plan: {plan}\n"
        "All findings so far (last item is the newest): {findings}\n\n"
        "Decide whether the loop is DONE or must REFINE, using these rules "
        "in order:\n"
        "1. If the newest finding has coverage 'none' -> verdict refine, "
        "reason incomplete, and rephrase the question more broadly.\n"
        "2. If the newest finding lists unresolved_conflicts -> verdict "
        "refine, reason conflict. Use the first suggested_followups entry "
        "as the refined_question if present, otherwise write a targeted "
        "question that would settle the conflict.\n"
        "3. If the newest finding contradicts an earlier finding -> verdict "
        "refine, reason competing, with a question targeting the "
        "discrepancy.\n"
        "4. If any plan sub-question still has no finding -> verdict "
        "refine, reason incomplete, refined_question = that sub-question.\n"
        "5. Otherwise -> verdict done, empty reasons, no refined_question.\n\n"
        "Be strict: do not loop for marginal gains. One clean, "
        "evidence-backed answer per sub-question is enough."
    ),
    output_schema=LoopStatus,
    output_key="loop_status",
)
