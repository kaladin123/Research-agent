"""Step 6 -- Reconcile: tier-2, cross-round conflict resolution.

Deliberately a SEPARATE agent from synthesis (the Rally mermaid draws
FINALCONFLICT and RESP as distinct nodes). If reconciliation were buried in
the synthesis prompt, there would be nothing to point at in a demo when
asked to prove that 'conflicting evidence is identified and handled rather
than ignored'. As its own step, the resolution is a visible, auditable
event in the run.

With one pilot LOB, cross-ROUND reconciliation is the stand-in for the
eventual cross-LOB reconciliation -- same seat, bigger job later.
"""

import os
import sys

from google.adk.agents import LlmAgent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from central_research_agent.config import azure_model  # noqa: E402
from common.contracts import Reconciliation  # noqa: E402

reconcile_agent = LlmAgent(
    name="reconcile_agent",
    model=azure_model(),
    description="Resolves contradictions across loop rounds before synthesis.",
    instruction=(
        "You are the cross-round reconciliation step of a central research "
        "agent. The consultation loop has finished.\n\n"
        "Original query: {original_query}\n"
        "All findings across rounds: {findings}\n"
        "Loop exit info: {loop_exit?}\n\n"
        "Identify contradictions ACROSS rounds (including any "
        "unresolved_conflicts escalated by the LOB agent that later rounds "
        "may have settled). For each, decide the resolution using evidence "
        "strength, in this priority order: current production/deployment "
        "evidence > code behavior > process documentation (SIPOCs, "
        "runbooks); prefer newer evidence over older. Name the "
        "winning_source_id for each resolution.\n\n"
        "If a conflict genuinely cannot be resolved from the available "
        "evidence, say so in notes -- do NOT invent a resolution. If there "
        "are no conflicts, return conflicts_found=false with a short note."
    ),
    output_schema=Reconciliation,
    output_key="reconciliation",
)
