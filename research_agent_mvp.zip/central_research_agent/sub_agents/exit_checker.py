"""Step 5b -- ExitChecker: the deterministic loop gate.

A custom BaseAgent, NOT an LlmAgent, so the exit decision is code, not
sampling. Full exit contract:

    exit when  verdict == done
           OR  no progress (newest finding is a repeat of a previous one)
           OR  LoopAgent max_iterations reached (handled by the framework)

Escalating (EventActions.escalate=True) is how a sub-agent breaks a
LoopAgent in ADK. On a forced exit (no-progress / max iterations) the
downstream reconcile + synthesis agents see partial findings and must caveat
-- that is the difference between a demo that survives a hostile question
and one that hangs or claims false completeness.
"""

import hashlib
import json
from typing import AsyncGenerator

from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events import Event, EventActions


def _finding_hash(finding: dict) -> str:
    core = json.dumps(
        {"finding": finding.get("finding", ""), "coverage": finding.get("coverage")},
        sort_keys=True,
    )
    return hashlib.sha256(core.encode()).hexdigest()


class ExitChecker(BaseAgent):
    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        state = ctx.session.state

        status = state.get("loop_status", {})
        if isinstance(status, str):
            try:
                status = json.loads(status)
            except json.JSONDecodeError:
                status = {}

        findings = state.get("findings", [])
        seen_hashes = list(state.get("finding_hashes", []))

        newest_hash = _finding_hash(findings[-1]) if findings else ""
        no_progress = newest_hash in seen_hashes
        if newest_hash:
            seen_hashes.append(newest_hash)

        verdict_done = status.get("verdict") == "done"
        should_exit = verdict_done or no_progress

        state_delta = {
            "finding_hashes": seen_hashes,
            "loop_exit": {
                "exited": should_exit,
                "cause": (
                    "done"
                    if verdict_done
                    else "no_progress"
                    if no_progress
                    else "continue"
                ),
            },
        }

        yield Event(
            author=self.name,
            actions=EventActions(state_delta=state_delta, escalate=should_exit),
        )


exit_checker = ExitChecker(name="exit_checker")
