"""Steps 3-4 -- Consult: ask the USP LOB agent one question over MCP.

This agent uses tools, so it CANNOT have an output_schema (ADK constraint:
output_schema disables tool use). It writes the raw tool JSON to
state['last_finding']; the deterministic RecordFinding agent parses and
appends it to state['findings'].
"""

import os
import sys

from google.adk.agents import LlmAgent

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from central_research_agent.config import azure_model, usp_mcp_toolset  # noqa: E402

consult_agent = LlmAgent(
    name="consult_agent",
    model=azure_model(),
    description="Consults the USP LOB agent over MCP for one sub-question.",
    instruction=(
        "You are the consultation step of a central research agent, inside "
        "an iterative research loop.\n\n"
        "Original query: {original_query}\n"
        "Consultation plan: {plan}\n"
        "Findings collected so far: {findings}\n"
        "Latest loop status: {loop_status?}\n\n"
        "Decide the ONE question to ask this iteration:\n"
        "- If loop status contains a refined_question, ask exactly that.\n"
        "- Otherwise ask the next plan sub-question that has no finding yet.\n\n"
        "Call the usp_research tool exactly once with that question. Pass "
        "context with the original_query, a one-sentence "
        "prior_findings_summary (or 'none' on the first iteration), and the "
        "iteration number.\n\n"
        "Then output ONLY the raw JSON object returned by the tool -- no "
        "commentary, no markdown fences."
    ),
    tools=[usp_mcp_toolset()],
    output_key="last_finding",
)
