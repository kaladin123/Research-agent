"""AgentCard + AgentSkill for the USP LOB Agent (mandatory A2A compliance).

The skill mirrors the MCP tool 1:1 -- same name, same coarse-grained
contract -- so A2A compatibility does not change the federation boundary:
one question in, one synthesized finding out, reasoning stays inside USP.
"""

from a2a.types import AgentCapabilities, AgentCard, AgentSkill

USP_RESEARCH_SKILL = AgentSkill(
    id="usp_research",
    name="USP domain research",
    description=(
        "Answers a research question using USP-owned knowledge (SIPOCs, "
        "codebases, SharePoint, docs). Retrieval runs across per-source "
        "channels, fused with reciprocal rank fusion tuned by USP. Source "
        "conflicts are resolved locally where an authoritative source "
        "settles them and escalated in unresolved_conflicts otherwise. "
        "Returns a JSON UspResearchResponse: finding, confidence, coverage, "
        "evidence[], unresolved_conflicts[], suggested_followups[]."
    ),
    tags=["usp", "research", "federated", "rrf", "knowledge-base", "lob"],
    examples=[
        "How does the ingestion pipeline handle failures and retries?",
        "Which retry behavior is deployed in production?",
        '{"sub_question": "What are the ingestion pipeline stages?", '
        '"context": {"iteration": 1}}',
    ],
)

def usp_agent_card(base_url: str) -> AgentCard:
    return AgentCard(
        name="usp-lob-agent",
        description=(
            "USP LOB Agent / Context Engine. Self-contained domain "
            "intelligence unit for the USP line of business: owns its "
            "knowledge sources, ranking, and conflict policy. Part of the "
            "federated Research Agent architecture (F1872578)."
        ),
        url=base_url,
        version="0.1.0",
        default_input_modes=["text"],
        default_output_modes=["text"],
        capabilities=AgentCapabilities(streaming=False),
        skills=[USP_RESEARCH_SKILL],
    )
