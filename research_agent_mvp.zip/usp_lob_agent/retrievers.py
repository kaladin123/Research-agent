"""Per-source retrievers for the USP context engine.

Each knowledge source (SIPOCs, codebase, SharePoint/docs) gets its own
retrieval channel returning its own ranked list; the context engine fuses
them with RRF. In production these become real retrievers (vector search
over the migrated USP vector stores, code search, etc.) -- the interface
stays the same, which is the point of the service boundary.

The demo corpus is deliberately seeded with a tier-1 conflict:
the ingestion SIPOC says retries are MANUAL, the retry coordinator code says
they are AUTOMATIC. A deployment note (found only when the loop refines its
question toward "what is deployed in production") resolves it. This makes the
full demo arc -- conflict detected -> escalated -> loop refines -> resolved --
reproducible without any external infrastructure.
"""

from dataclasses import dataclass, field


@dataclass
class Doc:
    doc_id: str
    source_type: str  # sipoc | codebase | sharepoint | doc
    text: str
    keywords: set[str]
    # Structured claims used for deterministic conflict detection in the demo.
    # topic -> value. Same topic + different value across sources = conflict.
    claims: dict[str, str] = field(default_factory=dict)
    # Authoritative sources (e.g. production deployment notes) settle claim
    # conflicts locally instead of escalating them.
    authoritative: bool = False


CORPUS: list[Doc] = [
    Doc(
        doc_id="sipoc/ingestion-v2",
        source_type="sipoc",
        text=(
            "Ingestion SIPOC v2: Suppliers push source documents into the "
            "staging area. Process: fetch -> validate -> chunk -> vectorize "
            "-> index. On failure, the batch is logged to the error queue "
            "and a MANUAL retry is initiated by the operations team after "
            "triage."
        ),
        keywords={"ingestion", "failure", "failures", "retry", "retries",
                  "error", "process", "pipeline", "sipoc"},
        claims={"retry_mode": "manual"},
    ),
    Doc(
        doc_id="repo/ingestion/retry_coordinator.py#L40-88",
        source_type="codebase",
        text=(
            "def retry_with_backoff(batch, max_attempts=3): ...  # Automatic "
            "retry: failed batches are re-enqueued with exponential backoff "
            "(2s, 8s, 32s). After max_attempts the batch moves to the "
            "dead-letter queue and an alert fires."
        ),
        keywords={"ingestion", "failure", "failures", "retry", "retries",
                  "backoff", "code", "coordinator", "dead-letter"},
        claims={"retry_mode": "automatic"},
    ),
    Doc(
        doc_id="sp/ingestion-runbook",
        source_type="sharepoint",
        text=(
            "Ingestion runbook: pipeline stages are fetch, validate, chunk, "
            "vectorize, index. Monitoring dashboards live under "
            "Ops > Ingestion. Alerts route to the platform on-call channel."
        ),
        keywords={"ingestion", "runbook", "pipeline", "stages", "monitoring",
                  "alerts", "failure", "failures"},
    ),
    Doc(
        doc_id="sp/deployment-notes-2026-06",
        source_type="sharepoint",
        text=(
            "June 2026 deployment notes: the automatic retry coordinator is "
            "ENABLED in production as of release 26.6. The legacy manual "
            "retry path described in older SIPOCs is deprecated and the "
            "SIPOC is pending update."
        ),
        keywords={"deployment", "deployed", "production", "prod", "release",
                  "retry", "current", "enabled", "behavior", "authoritative",
                  "mode"},
        claims={"retry_mode": "automatic"},
        authoritative=True,
    ),
    Doc(
        doc_id="doc/architecture-overview",
        source_type="doc",
        text=(
            "USP architecture overview: the LOB owns its ingestion pipeline, "
            "vector stores, and ranking configuration. External systems "
            "interact through the repo API (operational) and the LOB agent "
            "over MCP (research)."
        ),
        keywords={"architecture", "overview", "usp", "mcp", "api",
                  "vector", "stores"},
    ),
]


def _tokenize(text: str) -> set[str]:
    return {t.strip(".,?!:;()\"'").lower() for t in text.split() if len(t) > 2}


def _score(query_tokens: set[str], doc: Doc) -> float:
    kw_hits = len(query_tokens & doc.keywords)
    text_hits = len(query_tokens & _tokenize(doc.text))
    return kw_hits * 2.0 + text_hits * 0.5


def retrieve_channel(source_type: str, query: str, top_k: int = 3,
                     min_score: float = 2.0) -> list[str]:
    """One retrieval channel = one source type. Returns doc_ids best-first."""
    q = _tokenize(query)
    scored = [
        (doc.doc_id, _score(q, doc))
        for doc in CORPUS
        if doc.source_type == source_type
    ]
    scored = [(d, s) for d, s in scored if s >= min_score]
    scored.sort(key=lambda kv: kv[1], reverse=True)
    return [d for d, _ in scored[:top_k]]


def retrieve_all_channels(query: str) -> dict[str, list[str]]:
    """Run every per-source channel. Input to RRF."""
    channels = {}
    for source_type in ("sipoc", "codebase", "sharepoint", "doc"):
        ranked = retrieve_channel(source_type, query)
        if ranked:
            channels[source_type] = ranked
    return channels


def get_doc(doc_id: str) -> Doc:
    return next(d for d in CORPUS if d.doc_id == doc_id)
