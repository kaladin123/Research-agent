"""USP LOB Agent -- A2A server (compliance-mandated peer exposure).

Same context engine as the MCP server; second transport. Dual exposure:

  MCP  :8001/mcp                      -- RA <-> LOB interaction layer per F1872578
  A2A  :8002 (card at /.well-known/)  -- AgentCard + AgentSkill per internal rule

Input: either a plain-text question, or a JSON object matching
UspResearchRequest (sub_question / context / constraints).
Output: JSON UspResearchResponse -- identical contract to the MCP tool.

Run:  python -m usp_lob_agent.a2a_server
"""

import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.a2a_wrapper import serve_a2a  # noqa: E402
from common.contracts import UspResearchRequest  # noqa: E402
from usp_lob_agent.agent_card import usp_agent_card  # noqa: E402
from usp_lob_agent.context_engine import research  # noqa: E402

HOST = os.getenv("USP_A2A_HOST", "0.0.0.0")
PORT = int(os.getenv("USP_A2A_PORT", "8002"))
BASE_URL = os.getenv("USP_A2A_URL", f"http://localhost:{PORT}")


async def handle(user_input: str) -> str:
    text = user_input.strip()
    try:
        payload = json.loads(text)
        request = UspResearchRequest(**payload)
    except (json.JSONDecodeError, TypeError, ValueError):
        request = UspResearchRequest(sub_question=text)

    response = await research(request)
    return response.model_dump_json()


if __name__ == "__main__":
    serve_a2a(usp_agent_card(BASE_URL), handle, HOST, PORT)
