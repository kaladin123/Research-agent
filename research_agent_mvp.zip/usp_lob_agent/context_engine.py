"""USP Context Engine: the tier-1 pipeline that runs INSIDE the LOB boundary.

    retrieve (per-source channels) -> RRF fuse -> detect source conflicts
    -> synthesize one finding -> return over MCP

The Research Agent never sees any of this -- it receives only the
UspResearchResponse. Ranking, source composition, and conflict policy are
USP-owned and tunable here without any change to the central agent.
"""

import os
import sys
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.contracts import (  # noqa: E402
    ConflictPosition,
    Evidence,
    UnresolvedConflict,
    UspResearchRequest,
    UspResearchResponse,
)
from usp_lob_agent.retrievers import get_doc, retrieve_all_channels  # noqa: E402
from usp_lob_agent.rrf import reciprocal_rank_fusion  # noqa: E402

SYNTH_MODEL = os.getenv("USP_SYNTH_MODEL", "azure/gpt-4.1")


def _detect_conflicts(
    doc_ids: list[str],
) -> tuple[list[UnresolvedConflict], list[str]]:
    """Tier-1 conflict detection across the retrieved set.

    Demo implementation: compares structured claims attached to corpus docs.
    Same topic, different values, different sources = conflict. In production
    this becomes an LLM comparison pass over the retrieved excerpts.

    Policy -- resolve what we can, escalate what we can't:
    - If an AUTHORITATIVE source (e.g. production deployment notes) takes a
      position, the conflict is resolved LOCALLY in its favor and reported
      as a resolution note inside the finding.
    - Otherwise the conflict is ESCALATED via unresolved_conflicts so the
      Research Agent can refine its question, rather than the LOB guessing.

    Returns (unresolved_conflicts, local_resolution_notes).
    """
    by_topic: dict[str, dict[str, list[str]]] = defaultdict(lambda: defaultdict(list))
    for doc_id in doc_ids:
        for topic, value in get_doc(doc_id).claims.items():
            by_topic[topic][value].append(doc_id)

    unresolved, resolved_notes = [], []
    for topic, values in by_topic.items():
        if len(values) <= 1:
            continue

        authoritative = [
            (value, doc_id)
            for value, ids in values.items()
            for doc_id in ids
            if get_doc(doc_id).authoritative
        ]
        if authoritative:
            value, doc_id = authoritative[0]
            losing = sorted(v for v in values if v != value)
            resolved_notes.append(
                f"Conflict on '{topic}' resolved locally: '{value}' per "
                f"authoritative source [{doc_id}]; superseded position(s): "
                + ", ".join(losing)
            )
            continue

        positions = [
            ConflictPosition(claim=f"{topic} = {value}", source_id=doc_ids_[0])
            for value, doc_ids_ in values.items()
        ]
        unresolved.append(
            UnresolvedConflict(
                description=(
                    f"Sources disagree on '{topic}': "
                    + " vs ".join(sorted(values.keys()))
                ),
                positions=positions,
            )
        )
    return unresolved, resolved_notes


def _followups(conflicts: list[UnresolvedConflict]) -> list[str]:
    return [
        "Which "
        + c.description.split("'")[1].replace("_", " ")
        + " is authoritative in the current production deployment?"
        for c in conflicts
    ]


async def _synthesize(question: str, evidence: list[Evidence]) -> str:
    """Write one finding from the fused evidence.

    Tries the LLM (Azure OpenAI via LiteLLM); falls back to a deterministic
    template so the end-to-end demo runs even without credentials.
    """
    excerpts = "\n".join(
        f"[{e.fused_rank}] ({e.source_type}) {e.source_id}: {e.excerpt}"
        for e in evidence
    )
    try:
        import litellm

        resp = await litellm.acompletion(
            model=SYNTH_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are the USP domain expert. Answer the question "
                        "using ONLY the evidence excerpts. Cite source_ids "
                        "inline in square brackets. 2-4 sentences."
                    ),
                },
                {
                    "role": "user",
                    "content": f"Question: {question}\n\nEvidence:\n{excerpts}",
                },
            ],
            max_tokens=300,
        )
        return resp.choices[0].message.content.strip()
    except Exception:
        top = evidence[:3]
        cited = "; ".join(f"{e.excerpt[:140]}... [{e.source_id}]" for e in top)
        return f"Based on USP sources: {cited}"


async def research(request: UspResearchRequest) -> UspResearchResponse:
    channels = retrieve_all_channels(request.sub_question)

    if not channels:
        return UspResearchResponse(
            finding="No relevant USP knowledge found for this question.",
            confidence="low",
            coverage="none",
        )

    fused = reciprocal_rank_fusion(channels)
    top_ids = [doc_id for doc_id, _ in fused[:5]]

    evidence = [
        Evidence(
            source_type=get_doc(doc_id).source_type,
            source_id=doc_id,
            excerpt=get_doc(doc_id).text[:220],
            fused_rank=rank,
        )
        for rank, doc_id in enumerate(top_ids, start=1)
    ]

    unresolved, resolved_notes = _detect_conflicts(top_ids)
    finding = await _synthesize(request.sub_question, evidence)
    if resolved_notes:
        finding += " " + " ".join(resolved_notes)

    if unresolved:
        coverage, confidence = "partial", "medium"
    elif len(top_ids) >= 2:
        coverage, confidence = "full", "high"
    else:
        coverage, confidence = "partial", "medium"

    return UspResearchResponse(
        finding=finding,
        confidence=confidence,
        coverage=coverage,
        evidence=evidence,
        unresolved_conflicts=unresolved,
        suggested_followups=_followups(unresolved),
    )
