"""USP LOB Agent -- MCP server.

Exposes exactly ONE coarse-grained tool: usp_research. Deliberately NOT
search_sipocs / search_codebase / search_sharepoint -- fine-grained tools
would pull source selection, weighting, and merging back into the central
Research Agent and silently violate the federation principle. The RA asks a
question; USP answers it.

Run:  python -m usp_lob_agent.server
Serves streamable HTTP at http://localhost:8001/mcp
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from mcp.server.fastmcp import FastMCP  # noqa: E402

from common.contracts import UspResearchRequest  # noqa: E402
from usp_lob_agent.context_engine import research  # noqa: E402

mcp = FastMCP(
    "usp-lob-agent",
    host=os.getenv("USP_MCP_HOST", "0.0.0.0"),
    port=int(os.getenv("USP_MCP_PORT", "8001")),
)


@mcp.tool()
async def usp_research(
    sub_question: str,
    context: dict | None = None,
    constraints: dict | None = None,
) -> dict:
    """Ask the USP domain expert a research question.

    USP retrieves across its own knowledge sources (SIPOCs, codebase,
    SharePoint, docs), applies USP-tuned ranking and reciprocal rank fusion,
    resolves source conflicts where it can, and returns ONE synthesized
    finding with evidence. Conflicts it cannot resolve locally are escalated
    in unresolved_conflicts, with suggested_followups to sharpen the next
    iteration.
    """
    request = UspResearchRequest(
        sub_question=sub_question,
        context=context or {},
        constraints=constraints or {},
    )
    response = await research(request)
    return response.model_dump()


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
