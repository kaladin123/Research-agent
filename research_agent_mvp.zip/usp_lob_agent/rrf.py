"""Reciprocal rank fusion.

Merges ranked lists from multiple retrieval channels (per-source retrievers)
into one fused ranking. RRF is rank-based, so per-channel scores don't need
to be comparable -- which is exactly why the spec calls for it when fusing
heterogeneous sources (SIPOCs vs codebase vs SharePoint).

    score(d) = sum over channels of  1 / (k + rank_c(d))

k=60 is the standard damping constant from the original RRF paper.
"""

from collections import defaultdict


def reciprocal_rank_fusion(
    ranked_lists: dict[str, list[str]], k: int = 60
) -> list[tuple[str, float]]:
    """ranked_lists: {channel_name: [doc_id best-first, ...]}.

    Returns [(doc_id, fused_score), ...] best-first.
    """
    scores: dict[str, float] = defaultdict(float)
    for _channel, doc_ids in ranked_lists.items():
        for rank, doc_id in enumerate(doc_ids, start=1):
            scores[doc_id] += 1.0 / (k + rank)
    return sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
