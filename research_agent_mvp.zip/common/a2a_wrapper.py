"""Generic A2A exposure for any agent backed by an async handler.

Internal compliance rule: every agent must be A2A-compatible, publishing an
AgentCard with at least one AgentSkill. This wrapper turns an async
`handler(user_input: str) -> str` into a spec-compliant A2A server:

  - AgentCard served at /.well-known/agent-card.json
    (a2a-sdk also serves the legacy /.well-known/agent.json)
  - message/send (JSON-RPC) invokes the handler

Pinned to a2a-sdk 0.x -- the API line Google ADK's A2A integration and
RemoteA2aAgent are built against. a2a-sdk 1.x is a protobuf-based rewrite
with a different server layout; migrate deliberately, not by accident.
"""

import json
from typing import Awaitable, Callable

import uvicorn
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.apps import A2AStarletteApplication
from a2a.server.events import EventQueue
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.types import AgentCard
from a2a.utils import new_agent_text_message

Handler = Callable[[str], Awaitable[str]]


class CallableAgentExecutor(AgentExecutor):
    """Bridges the A2A protocol to a plain async handler."""

    def __init__(self, handler: Handler):
        self._handler = handler

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        user_input = context.get_user_input()
        try:
            result = await self._handler(user_input)
        except Exception as exc:  # protocol-level failure boundary
            result = json.dumps({"error": f"{type(exc).__name__}: {exc}"})
        await event_queue.enqueue_event(new_agent_text_message(result))

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("cancel is not supported by this agent")


def serve_a2a(agent_card: AgentCard, handler: Handler, host: str, port: int) -> None:
    request_handler = DefaultRequestHandler(
        agent_executor=CallableAgentExecutor(handler),
        task_store=InMemoryTaskStore(),
    )
    app = A2AStarletteApplication(agent_card=agent_card, http_handler=request_handler)
    uvicorn.run(app.build(), host=host, port=port)
