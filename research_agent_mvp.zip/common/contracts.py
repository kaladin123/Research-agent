"""Shared contract between the central Research Agent and LOB agents.

This is the federation boundary. Any LOB (USP today, Optum Rx / XLOB later)
implements the same request/response shape, exposed as an MCP tool named
`<lob>_research`. The Research Agent never sees raw documents or vector
stores -- only this structured finding.
"""

from typing import Literal, Optional

from pydantic import BaseModel, Field

SourceType = Literal["sipoc", "codebase", "sharepoint", "doc"]


class Evidence(BaseModel):
    """One supporting citation behind a finding."""

    source_type: SourceType
    source_id: str
    excerpt: str
    fused_rank: int = Field(
        description="Position of this source after reciprocal rank fusion. "
        "Proves ranking/fusion ran behind the LOB boundary without exposing "
        "how it is tuned."
    )


class ConflictPosition(BaseModel):
    claim: str
    source_id: str


class UnresolvedConflict(BaseModel):
    """A tier-1 conflict the LOB agent could NOT resolve locally.

    This is the escalation channel: the LOB resolves what it can and
    escalates what it can't, so conflicts are handled rather than silently
    papered over or dropped.
    """

    description: str
    positions: list[ConflictPosition]


class UspResearchRequest(BaseModel):
    sub_question: str
    context: dict = Field(
        default_factory=dict,
        description="original_query, prior_findings_summary, iteration. The "
        "LOB agent is stateless across calls; loop memory lives in the "
        "Research Agent's session and just enough is passed here.",
    )
    constraints: dict = Field(default_factory=dict)


class UspResearchResponse(BaseModel):
    finding: str
    confidence: Literal["high", "medium", "low"]
    coverage: Literal["full", "partial", "none"] = Field(
        description="Structured signal for the deterministic loop exit: the "
        "evaluator reads this instead of vibe-checking prose."
    )
    evidence: list[Evidence] = Field(default_factory=list)
    unresolved_conflicts: list[UnresolvedConflict] = Field(default_factory=list)
    suggested_followups: list[str] = Field(default_factory=list)
    error: Optional[str] = None


# ---- Central Research Agent internal state schemas ----


class PlanStep(BaseModel):
    order: int
    sub_question: str
    domain: str = "USP"
    rationale: str = ""


class ConsultationPlan(BaseModel):
    steps: list[PlanStep]


class Decomposition(BaseModel):
    sub_questions: list[str]


class LoopStatus(BaseModel):
    """Written by the evaluator each iteration; read by the ExitChecker.

    Promoted from a single conflict_detected boolean because the spec names
    three loop-continue reasons: conflicting, incomplete, or competing
    findings.
    """

    verdict: Literal["done", "refine"]
    reasons: list[Literal["conflict", "incomplete", "low_confidence", "competing"]] = Field(
        default_factory=list
    )
    refined_question: Optional[str] = None


class ResolvedConflict(BaseModel):
    description: str
    resolution: str
    winning_source_id: str


class Reconciliation(BaseModel):
    conflicts_found: bool
    resolutions: list[ResolvedConflict] = Field(default_factory=list)
    notes: str = ""
