"""A2A compliance smoke test.

Verifies the internal rule end to end:
  1. Each agent serves an AgentCard at /.well-known/agent-card.json
  2. Each card declares at least one AgentSkill
  3. The USP skill is actually invocable over A2A (message/send round trip)

Run (with the servers up):
  python a2a_smoke_test.py                 # checks USP (:8002) only
  python a2a_smoke_test.py --with-ra       # also checks the RA card (:8003)
"""

import asyncio
import json
import os
import sys
import uuid

import httpx
from a2a.client import A2ACardResolver, A2AClient
from a2a.types import MessageSendParams, SendMessageRequest

USP_A2A_URL = os.getenv("USP_A2A_URL", "http://localhost:8002")
RA_A2A_URL = os.getenv("RA_A2A_URL", "http://localhost:8003")


async def check_card(client: httpx.AsyncClient, base_url: str):
    resolver = A2ACardResolver(httpx_client=client, base_url=base_url)
    card = await resolver.get_agent_card()
    assert card.skills, f"{card.name}: AgentCard has no skills -- rule violated"
    print(f"[OK] {card.name} v{card.version} @ {base_url}")
    for skill in card.skills:
        print(f"     skill: {skill.id} -- {skill.name} (tags: {', '.join(skill.tags)})")
    return card


async def invoke_usp(client: httpx.AsyncClient, card) -> None:
    a2a_client = A2AClient(httpx_client=client, agent_card=card)
    request = SendMessageRequest(
        id=str(uuid.uuid4()),
        params=MessageSendParams(
            message={
                "role": "user",
                "parts": [
                    {
                        "kind": "text",
                        "text": "How does the ingestion pipeline handle "
                        "failures and retries?",
                    }
                ],
                "messageId": uuid.uuid4().hex,
            }
        ),
    )
    response = await a2a_client.send_message(request)
    data = response.model_dump(mode="python", exclude_none=True)
    result = data.get("result", {})
    parts = result.get("parts") or (
        result.get("status", {}).get("message", {}) or {}
    ).get("parts", [])
    text = next(
        (p.get("text") or p.get("root", {}).get("text") for p in parts), None
    )
    finding = json.loads(text)
    print(f"[OK] usp_research invoked over A2A")
    print(f"     coverage={finding['coverage']} confidence={finding['confidence']}")
    print(f"     conflicts={[c['description'] for c in finding['unresolved_conflicts']]}")


async def main() -> None:
    async with httpx.AsyncClient(timeout=60.0) as client:
        usp_card = await check_card(client, USP_A2A_URL)
        await invoke_usp(client, usp_card)
        if "--with-ra" in sys.argv:
            await check_card(client, RA_A2A_URL)
    print("\nA2A compliance: PASS")


if __name__ == "__main__":
    asyncio.run(main())
